<?php
session_start();

if(isset($_session['counter']))
	$_session['counter']+=1;
	else
	$_session['counter']=1;
include("header.php");
?>