<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>My Bootstrap Offline Page</title>

  <!-- Use local Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/home.css" rel="stylesheet">
</head>
<body>
<?php
$connection = mysqli_connect("localhost", "root", "", "Electron");

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
  <!-- Navbar -->

  
     

  

  <!-- Use local Bootstrap JS -->
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
