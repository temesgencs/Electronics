<!DOCTYPE html>
<html lang="en">

<style>

.lefthomesidenavbar{
float:center;

}
.navleftsidemenu{
 background-color: rgba(151, 133, 144, 1);

border:rgb(136, 164, 155) 5px solid;
height:40px;
}
.navleftsidemenu>.container-fluid>.leftsidemenu>.navbar-brand{
padding: 80px;
  text-shadow:rgb(95, 94, 97) ;
  font-size: 18PX;
  font-family: 'Times New Roman', Times, serif;
}
 </style>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>My Bootstrap Offline Page</title>

  <!-- Use local Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/home.css" rel="stylesheet">
</head>

<body>
<?php
$connection = mysqli_connect("localhost", "root", "", "Electron");

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
  
}
?>
  
  <!-- Navbar -->
<div class="container-fluid bg-cyan">
    <div class="lefthomesidenavbar">
    <nav class="navleftsidemenu">
        <div class="container-fluid ">
<div class="leftsidemenu">
      <a class="navbar-brand" href="#" target="center"> Home</a>
      <div> 
				<script src="js/dateandtime.js"></script>
				<script type="text/javascript">
				var calendarDate = getCalendarDate();
				document.write(calendarDate);
				</script>
				<form name="clock">
				<input type="submit" class="trans" name="face" value="" style="color: #fff;border: fff 5px solid;background-color: #777;">
			</form>
		</div>
      
      <a class="navbar-brand" href="#"> Feedback</a>
      <a class="navbar-brand" href="#"> Contact us</a>
      <a class="navbar-brand" href="#"> Help</a>
     <a class="navbar-brand" href="#"> Login</a>




    </div>
     </div>
     </nav>


</div>
  
    </div> 

  

  <!-- Use local Bootstrap JS -->
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
