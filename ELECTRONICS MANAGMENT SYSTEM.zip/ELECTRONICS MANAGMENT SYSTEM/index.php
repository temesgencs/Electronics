<!DOCTYPE html>
<html lang="en">
<style>
   #container-fluid{
     border:  rgba(89, 97, 85, 1) 10px solid;

  }
.col-6{

     border:rgb(51, 105, 103) 10px solid;


}
</style>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title></title>
  <link href="css/bootstrap.min.css" rel="stylesheet"> <!-- Use your local or CDN CSS -->
    <link href="css/home.css" rel="stylesheet">
</head>

<body>
  <div class="container-fluid" id="container-fluid">
    <div class="row mx text-center">
      <div class="col-12 ">
          </div>

<?php
$connection = mysqli_connect("localhost", "root", "", "Electron");

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
  
}
  include("header.php");
?>
          <div class="col-3">
<?php
  include("leftsidehomemenu.php");

?>                
      </div>
      <div class="col-6">
       <form>
      <div class="row mb-3">
        <div class="col-md-6">
          <label for="firstName" class="form-label">First Name</label>
          <input type="text" class="form-control" id="firstName" placeholder="John">
        </div>
        <div class="col-md-6">
          <label for="lastName" class="form-label">Last Name</label>
          <input type="text" class="form-control" id="lastName" placeholder="Doe">
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-md-6">
          <label for="email" class="form-label">Email Address</label>
          <input type="email" class="form-control" id="email" placeholder="you@example.com">
        </div>
        <div class="col-md-6">
          <label for="phone" class="form-label">Phone</label>
          <input type="tel" class="form-control" id="phone" placeholder="+1234567890">
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-md-8">
          <label for="address" class="form-label">Address</label>
          <input type="text" class="form-control" id="address" placeholder="123 Main St">
        </div>
        <div class="col-md-4">
          <label for="zip" class="form-label">ZIP Code</label>
          <input type="text" class="form-control" id="zip" placeholder="10001">
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-md-4">
          <label for="city" class="form-label">City</label>
          <input type="text" class="form-control" id="city">
        </div>
        <div class="col-md-4">
          <label for="state" class="form-label">State</label>
          <input type="text" class="form-control" id="state">
        </div>
        <div class="col-md-4">
          <label for="country" class="form-label">Country</label>
          <select id="country" class="form-select">
            <option selected>Choose...</option>
            <option>USA</option>
            <option>UK</option>
            <option>Ethiopia</option>
            <option>Other</option>
          </select>
        </div>
      </div>

      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
      <div class="col-3">
<?php
  include("rightsidehomemenu.php");

?>       </div>
      
    </div>
    <div class="row mx text-center">
  <div class="col-12">
        <h1> hello</h1>
      </div>
    </row>
  </div>
  <script src="js/bootstrap.bundle.min.js"></script> <!-- Use your local or CDN JS -->
</body>

</html>